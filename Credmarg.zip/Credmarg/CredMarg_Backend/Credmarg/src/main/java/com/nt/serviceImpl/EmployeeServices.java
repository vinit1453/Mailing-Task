package com.nt.serviceImpl;

import java.sql.SQLDataException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.nt.custom.CustomException;
import com.nt.entity.Employee;
import com.nt.repositories.Employee_Repository;
import com.nt.services.IEmployeeServices;

@Service("Employee_Services")
public class EmployeeServices implements IEmployeeServices {

	@Autowired
	Employee_Repository empRepo;

	@Override
	public Employee addEmployee(Employee e) throws CustomException {
			 
			Optional<Employee> emp= empRepo.findByEmail(e.getEmail());
			if(emp.isPresent()) {
				throw new CustomException("Employee email already Exists");
			}
			Employee addedEmployee = empRepo.save(e);
			if (addedEmployee == null || addedEmployee.getId() == "") {
				throw new CustomException("unable to insert Employee");
			}
			return addedEmployee;
		
	}

	@Override
	public boolean deleteEmployee(String id) throws NotFoundException {
		
		Optional<Employee> e = empRepo.findById(id);
		if (!e.isPresent()) {
			throw new CustomException("unable to Find Employee with given Id:-" + id);
		}
		empRepo.delete(e.get());
		//empRepo.deleteById(id);
		return true;
	}

	@Override
	public Employee updateEmployee(Employee e) throws CustomException {
		Employee updatedEmployee = empRepo.save(e);
		if (updatedEmployee == null || updatedEmployee.getId() == "") {
			throw new CustomException("unable to update Employee");
		}
		return updatedEmployee;
	}

	@Override
	public List<Employee> getAllEmployees() throws CustomException {

		return empRepo.findAll();
	}

}
