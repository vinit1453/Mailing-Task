package com.nt.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.custom.ApiResponse;
import com.nt.custom.CustomException;
import com.nt.custom.MultipleEmailRequest;
import com.nt.serviceImpl.MailServices;

@Controller
@RequestMapping("api/mail")
public class Email_Contoller {

	@Autowired
	MailServices mailServices;

	

	@PostMapping("/sendEmails")
	public ResponseEntity<?> sendEmailsToMultiples(@RequestBody MultipleEmailRequest req) {

		try {
			Map<String, String> responseMapper = mailServices.sendEmailsToMultiples(req.getEmailsList());
			
			return ResponseEntity.ok(new ApiResponse(true, "Emails trigger successfully", responseMapper));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(false, "Unable to Process request", e1.getMessage()));
		}

	}
}
