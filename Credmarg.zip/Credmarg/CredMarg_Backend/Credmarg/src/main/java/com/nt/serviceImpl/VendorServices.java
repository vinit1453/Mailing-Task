package com.nt.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;

import com.nt.custom.CustomException;
import com.nt.entity.Employee;
import com.nt.entity.Vendor;
import com.nt.repositories.Vendor_Repository;
import com.nt.services.IVendorServices;

@Service("Vendor_Services")
public class VendorServices implements IVendorServices {
	
	@Autowired
	private Vendor_Repository vendorRepo;

	@Override
	public Vendor addVendor(Vendor v) throws CustomException {
		Optional<Vendor> vendor= vendorRepo.findByEmail(v.getEmail());
		if(vendor.isPresent()) {
			throw new CustomException("Email already Exists");
		}
		Vendor _v=vendorRepo.save(v);
		if(v==null || v.getId()=="") {
			throw new CustomException("unable to insert vendor");
		}
		return _v;
	}

	@Override
	public boolean deleteVendor(String id) throws NotFoundException {
		Optional<Vendor> v=vendorRepo.findById(id);
		if(!v.isPresent()) {
			throw new CustomException("unable to find vendor with Id:-"+id);
		}
		vendorRepo.delete(v.get());
		return true;
	}

	@Override
	public Vendor updateVendor(Vendor v) throws CustomException {
		Vendor updatedVendor=vendorRepo.save(v);
		if(v==null || v.getId()=="") {
			throw new CustomException("unable to insert vendor");
		}
		return updatedVendor;
	}

	

	@Override
	public List<Vendor> getAllVendors() throws CustomException {
		return vendorRepo.findAll();
	}

}
