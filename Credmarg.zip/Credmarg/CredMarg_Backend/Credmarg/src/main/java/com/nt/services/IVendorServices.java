package com.nt.services;

import java.util.List;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.mail.MailException;

import com.nt.custom.CustomException;
import com.nt.entity.Vendor;

public interface IVendorServices {
	Vendor addVendor(Vendor v) throws CustomException;
	boolean deleteVendor(String id)throws NotFoundException;
	Vendor updateVendor(Vendor v) throws CustomException;
	List<Vendor> getAllVendors() throws CustomException;

	
}
