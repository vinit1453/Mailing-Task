package com.nt.custom;

import lombok.Data;

@Data
public class MultipleEmailRequest {

	String[] emailsList;
}
