package com.nt.custom;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiResponse {

	
	boolean state;
	String message;
	Object data;
}
