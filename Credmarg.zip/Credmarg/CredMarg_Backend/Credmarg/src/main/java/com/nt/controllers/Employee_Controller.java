package com.nt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.custom.ApiResponse;
import com.nt.custom.CustomException;
import com.nt.entity.Employee;
import com.nt.serviceImpl.EmployeeServices;

import jakarta.validation.Valid;

@Controller
@RequestMapping("api/employee")
public class Employee_Controller {

	@Autowired
	EmployeeServices empServices;
	

	@GetMapping("/employeeList")
	public ResponseEntity<?> getAllEmployees() {
		try {
			List<Employee> employeeList = empServices.getAllEmployees();
			return ResponseEntity.ok(new ApiResponse(true, "Employee Records fetched Succesfully", employeeList));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(false, "Unable to Process request",null));
		}

	}
	

	@PostMapping("/add")
	public ResponseEntity<?> addEmployee(@Valid @RequestBody Employee e) {
		try {
			Employee addedEmp = empServices.addEmployee(e);
			return ResponseEntity.ok(new ApiResponse(true, "Employee Record Added Succesfully", addedEmp));
		} catch (CustomException  e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(false, "Unable to Process request", null));
		}

	}

	@PostMapping("/update")
	public ResponseEntity<?> updateEmployee(@Valid @RequestBody Employee e) {
		try {
			//System.out.println("Employee_Controller.updateEmployee()");
			Employee updatedEmployee = empServices.updateEmployee(e);
			return ResponseEntity.ok(new ApiResponse(true, "Employee Record updated Succesfully", updatedEmployee));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(false, "Unable to Process request", e1.getMessage()));
		}

	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable String id) {
		try {
			boolean res = empServices.deleteEmployee(id);

			return ResponseEntity.ok(new ApiResponse(true, "Employee Record deleted Succesfully", ""));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			//e1.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(false, "Unable to Process request", null));
		}

	}

}
