package com.nt.custom;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig {
	/*we can override  WebMvcConfigures method  to define cross origins for entire application*/
	  @Bean
	    public WebMvcConfigurer corsConfigurer()
	    {
	        return new WebMvcConfigurer() {
	            @Override
	            public void addCorsMappings(CorsRegistry registry) {
	                registry.addMapping("/**").allowedOrigins("*").allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS");
	                
	                //using this registry we can customize the configs for cors functionality
	            }
	        };
	    }
	  
	  @Bean
		public SimpleMailMessage templateSimpleMessage() {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setText("This is the test email template for your email:\n%s\n");
			return message;
		}
}