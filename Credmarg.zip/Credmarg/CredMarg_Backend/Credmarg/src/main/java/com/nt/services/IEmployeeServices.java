package com.nt.services;

import java.sql.SQLDataException;
import java.util.List;

import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;

import com.nt.custom.CustomException;
import com.nt.entity.Employee;

public interface IEmployeeServices {
		Employee addEmployee(Employee e) throws CustomException;
		boolean deleteEmployee(String id)throws NotFoundException;
		Employee updateEmployee(Employee e) throws CustomException;
		
		List<Employee> getAllEmployees() throws CustomException;
		
}
