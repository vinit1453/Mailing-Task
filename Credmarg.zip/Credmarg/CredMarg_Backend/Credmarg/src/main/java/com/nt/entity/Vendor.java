package com.nt.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table(name = "Credmarg_Vendors",uniqueConstraints = @UniqueConstraint(columnNames = {"email"}))
public class Vendor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name="id",length = 50)
	private String id;

	@NotBlank(message = "vendor Name is mandatory")
	@Column(name="name",length = 50)
	private String name;

	@Email
	@NotBlank(message = "Vendor email is mandatory")
	@Column(name = "email", length = 50)
	private String email;

	@NotBlank(message = "Vendor Upi is mandatory")
	@Column(name="upi_Id",length = 50)
	private String upiId;
}
