package com.nt.serviceImpl;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.nt.custom.CustomException;
import com.nt.entity.Vendor;
import com.nt.repositories.Vendor_Repository;

import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;

@Service
public class MailServices {

	@Value("${app.fromEmail}")
	private static String from_EmailId = "dondapativinit@gmail.com";

	@Value("${app.emailSubject}")
	private static String emailSubject = "Payment From Credmarg";

	private static JavaMailSender emailSender;

	private static Vendor_Repository vendorRepo;

	public SimpleMailMessage template;

	public MailServices(SimpleMailMessage template, Vendor_Repository vendorRepo, JavaMailSender emailSender) {
		super();
		this.template = template;
		this.emailSender = emailSender;
		this.vendorRepo = vendorRepo;
	}

	public static void sendSimpleMessage(String to, String subject, String text) throws Exception {
		try {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom(from_EmailId);
			message.setTo(to);
			message.setSubject(subject);
			message.setText(text);
			emailSender.send(message);

		} catch (Exception e) {
			StringBuffer exceptionString = new StringBuffer(e.getMessage().toString());
			if (exceptionString.indexOf("Connection Exception") > 0) {
				throw new CustomException("Unable to Connect mail Server");
			} else if (exceptionString.indexOf("SendFailedException") > 0) {
				throw new CustomException("Invalid email address");
			} else if (exceptionString.indexOf("FileNotFoundException") > 0) {
				throw new CustomException("Unable to read the attachements");
			}
			throw new CustomException("unable to send email to:-" + to);
		}

	}

	/**
	 * Method which accepts multiple unique entity id's as parameter and get Map of emailID, status of email.
	 * */
	public Map<String, String> sendEmailsToMultiples(String[] emailIds) {
		Map<String, String> emailResponse = new HashMap<>();
		String status = "send";
		String vendorEmailId = "";

		for (String id : emailIds) {
			try {
				vendorEmailId = getEmailIdFromVendorID(id);
				validateEmail(vendorEmailId);
				String subject = emailSubject;
				String parsedText = parseMessgeToVendor(id);
				sendSimpleMessage(vendorEmailId, subject, parsedText);
				status = "sent";
			} catch (CustomException e) {
				// e.printStackTrace();
				status = e.getMessage();

			} catch (AddressException e) {
				status = "invalid email";
			} catch (MailSendException e) {
				status = "failed to send";
			} catch (MailException e) {
				status = "mail exception";
			} catch (Exception e) {
				System.out.println("MailServices.sendEmailsToMultiples()");
				status = "unable to Send email";
			}
			emailResponse.put(vendorEmailId, status);
		}

		return emailResponse;

	}

	private String parseMessgeToVendor(String id) {
		String template = "Sending payments to vendor { name } at upi { upi }";
		Optional<Vendor> v = vendorRepo.findById(id);
		if (!v.isPresent()) {
			throw new CustomException("vendor not Found with Id:-" + id);
		}
		Map<String, String> mapper = new HashMap<>();
		mapper.put("name", v.get().getName());
		mapper.put("upi", v.get().getUpiId());

		return replaceVariables(template, mapper);
	}

	/**
	 * Method to get emailId using entity unique id
	 * */
	private static String getEmailIdFromVendorID(String id) {

		Optional<Vendor> v = vendorRepo.findById(id);
		if (!v.isPresent()) {
			throw new CustomException("vendor email not identified");
		}

		return v.get().getEmail();
	}

	/**
	 * method replace all variable which are in format { var } with actual user data.
	 * @param template is accepts template as staring in which we need to replace the data.
	 * @param variables is map<key,value> where key is the actual variable ref to find in template,
	 * 		value is actual user data.
	 * */
	private String replaceVariables(String template, Map<String, String> variables) {
		// Regular expression to find placeholders like { var }
		Pattern pattern = Pattern.compile("\\{\\s*(\\w+)\\s*\\}");
		Matcher matcher = pattern.matcher(template);

		StringBuffer result = new StringBuffer();
		while (matcher.find()) {
			String variable = matcher.group(1);
			String replacement = variables.getOrDefault(variable, "");
			matcher.appendReplacement(result, replacement);
		}
		matcher.appendTail(result);
		return result.toString();
	}

	private void validateEmail(String email) throws AddressException {
		InternetAddress emailAddr = new InternetAddress(email);
		emailAddr.validate();
	}

}