package com.nt.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Employee;
import com.nt.entity.Vendor;

@Repository
public interface Vendor_Repository extends JpaRepository<Vendor, String> {
	Optional<Vendor> findByEmail(String email);

}
