package com.nt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.custom.ApiResponse;
import com.nt.custom.CustomException;
import com.nt.entity.Employee;
import com.nt.entity.Vendor;
import com.nt.serviceImpl.VendorServices;
import com.nt.serviceImpl.VendorServices;

@Controller
@RequestMapping("api/vendors")
public class Vendors_Controller {

	@Autowired
	VendorServices vendorServices;
	
	@GetMapping("/vendorsList")
	public ResponseEntity<?> getAllEmployees() {
		try {
			List<Vendor> vendorsList = vendorServices.getAllVendors();
			return ResponseEntity.ok(new ApiResponse(true, "vendor Records fetched Succesfully", vendorsList));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(true, "Unable to Process request", null));
		}

	}

	@PostMapping("/add")
	public ResponseEntity<?> addVendor(@RequestBody Vendor v) {
		try {
			Vendor addedVendor=vendorServices.addVendor(v);
			return ResponseEntity.ok(new ApiResponse(true, "New Vendor added Succesfully", addedVendor));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(true, "Unable to Process request", null));
		}

	}

	@PostMapping("/update")
	public ResponseEntity<?> updateVendor(@RequestBody Vendor e) {
		try {
			Vendor updatedVendor = vendorServices.updateVendor(e);
			return ResponseEntity.ok(new ApiResponse(true, "Vendor Record updated Succesfully", updatedVendor));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(true, "Unable to Process request", null));
		}

	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteVendor(@PathVariable String id) {
		try {
			boolean res = vendorServices.deleteVendor(id);

			return ResponseEntity.ok(new ApiResponse(true, "Vendor Record deleted Succesfully", ""));
		} catch (CustomException e1) {
			return ResponseEntity.ok(new ApiResponse(true, e1.getMessage(), null));
		} catch (Exception e1) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new ApiResponse(true, "Unable to Process request", null));
		}

	}
}
