import React, { useEffect, useState } from "react";

import { Formik, Form, Field, ErrorMessage, useFormik } from "formik";
import * as Yup from "yup";
import {
  getAllEmployees,
  createEmployee,
  updateanEmployee,
  deleteEmployees,
  Iemployee,
} from "../../services/api";

const empInitialValues = {
  id: "",
  name: "",
  email: "",
  designation: "",
  ctc: 0,
};
export default function EmployeeTable(props: any) {
  const [data, setData] = useState<Iemployee[] | undefined>();
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState(empInitialValues);
  const [initVlaues, setInitValues] = useState<Iemployee | undefined | any>({
    modalData,
  });

  const formSchema = Yup.object().shape({
    name: Yup.string()
      .min(2, "Name at least contains 2 characters")
      .matches(
        /^[A-Za-z][A-Za-z0-9 ]*$/,
        "Name cannot start with a number or special character"
      )
      .max(30, "Name cannot be more than 30 charatcers")
      .required("Name is required"),
    email: Yup.string()
      .email("Invalid email format")
      .required("Email is required"),
    designation: Yup.string().required("Designation is required"),
    ctc: Yup.number()
      .typeError("CTC must be a number")
      .positive("CTC must be greater than 0")
      .required("CTC is required"),
  });

  const formik = useFormik<any>({
    enableReinitialize: true,
    initialValues: initVlaues,
    validationSchema: formSchema,
    onSubmit: (values: any) => {
      handleSubmit(values);
    },
  });

  const fetchData = async () => {
    try {
      const res = await getAllEmployees();
      if (res?.state) {
        setData(res?.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const addEmployee = async (e: Iemployee) => {
    try {
      const res = await createEmployee(e);
      if (res?.state) {
        alert(res?.message);
      }
      fetchData();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const updateEmployee = async (e: Iemployee) => {
    try {
      const res = await updateanEmployee(e);
      if (res?.state) {
        alert(res?.message);
      }
      fetchData();
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleDelete = async (id: String) => {
    if (window.confirm("Are you sure want to Delete the item?")) {
      try {
        const res = await deleteEmployees(id);
        if (res?.state) {
          alert(res?.message);
        }
        fetchData();
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    }
  };

  const handleEdit = (item: any) => {
    setModalData(item);
    setShowModal(true);
  };

  const handleAdd = () => {
    setModalData(empInitialValues);
    setShowModal(true);
  };

  const handleSubmit = (e: Iemployee) => {
    if (e.id) {
      updateEmployee(e);
    } else {
      addEmployee(e);
    }
    handleModalClose();
  };

  const handleModalClose = () => {
    formik.resetForm();
    setShowModal(false);
  };
  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    setInitValues(modalData);
  }, [modalData]);

  return (
    <div className=" w-90 bg bg-secondary mt-2 p-2 rounded">
      <div className="w-75 mx-auto ">
        <button className="btn btn-primary rounded mb-2 " onClick={handleAdd}>
          Add
        </button>
        <h3 className="d-flex justify-content-around text-info">
          Employees Table
        </h3>
        <div className="table-responsive">
          <table className="table  table-striped table-hover table-bordered ">
            <thead>
              <tr>
                <th className="text-center">Sr.No</th>
                <th className="text-center">Name</th>
                <th className="text-center">Email</th>
                <th className="text-center">Designation</th>
                <th className="text-center">CTC-$/Annum</th>
                <th className="text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data?.length ? (
                data.map((item, index) => (
                  <>
                    <tr key={item.id as any}>
                      <td className="text-center">{(index + 1).toString()}</td>
                      <td className="text-center">{item.name.toString()}</td>
                      <td className="text-center">{item.email.toString()}</td>
                      <td className="text-center">
                        {item.designation.toString()}
                      </td>
                      <td className="text-center">{item.ctc.toString()}</td>
                      <td className="text-center">
                        <i
                          className="me-2 bi bi-pencil"
                          style={{ cursor: "pointer" }}
                          onClick={() => handleEdit(item)}
                        />
                        <i
                          className="bi bi-trash"
                          style={{ cursor: "pointer" }}
                          onClick={() => handleDelete(item?.id)}
                        />
                      </td>
                    </tr>
                  </>
                ))
              ) : (
                <>
                  <tr>
                    <td colSpan={6} className="mx-auto text-center">
                      No Records Found
                    </td>
                  </tr>
                </>
              )}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="modal show d-block" tabIndex={-1} role="dialog">
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">
                    {initVlaues.id ? "Edit Item" : "Add Item"}
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={handleModalClose}
                    aria-label="Close"
                  ></button>
                </div>
                <form onSubmit={formik.handleSubmit}>
                  <div className="modal-body">
                    <div className="mb-3">
                      <label htmlFor="name" className="form-label">
                        Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        name="name"
                        value={formik.values.name}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.name && formik.errors.name ? (
                        <small className="text-danger">
                          {formik.errors.name.toString()}
                        </small>
                      ) : null}
                    </div>
                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        name="email"
                        value={formik.values.email}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.email && formik.errors.email ? (
                        <small className="text-danger">
                          {formik.errors.email.toString()}
                        </small>
                      ) : null}
                    </div>
                    <div className="mb-3">
                      <label htmlFor="designation" className="form-label">
                        Designation
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="designation"
                        name="designation"
                        value={formik.values.designation}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.designation &&
                      formik.errors.designation ? (
                        <small className="text-danger">
                          {formik.errors.designation.toString()}
                        </small>
                      ) : null}
                    </div>
                    <div className="mb-3">
                      <label htmlFor="ctc" className="form-label">
                        CTC
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="ctc"
                        name="ctc"
                        value={formik.values.ctc}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.touched.ctc && formik.errors.ctc ? (
                        <small className="text-danger">
                          {formik.errors.ctc.toString()}
                        </small>
                      ) : null}
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={handleModalClose}
                    >
                      Close
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={!formik.isValid}
                    >
                      {initVlaues.id ? "Save changes" : "Add"}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
