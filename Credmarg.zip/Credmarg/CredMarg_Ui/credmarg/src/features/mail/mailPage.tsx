import React, { useState, useEffect } from "react";
import Select from "react-select";
import axios from "axios";
import { getAllVendors, sendMails } from "../../services/api";

export default function MailPage() {
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedVendors, setSelectedVendors] = useState([]);
  const [response, setResponse] = useState<any | undefined>({});
  // {"dondapativinit2000@gmail.com": "sent",    " kvn5178@gmail.com": "sent"}
  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    try {
      const res = await getAllVendors();
      if (res?.state) {
        const employeeOptions = res.data.map((employee: any) => ({
          value: employee.id,
          label: employee.name,
        }));
        setVendors(employeeOptions);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleSelectChange = (selectedOptions: any) => {
    setSelectedVendors(selectedOptions);
  };

  const handleButtonClick = async () => {
    setLoading(true);
    const selectedIds = selectedVendors.map((employee: any) => employee.value);

    try {
      const res = await sendMails(selectedIds);
      if (res?.state) {
        setResponse(res?.data);
        console.log(res?.data);
        alert(res?.message);
      }
    } catch (error) {
      console.error("Error calling API:", error);
    }
    setLoading(false);
  };

  return (
    <>
      <div className=" w-90 bg bg-secondary mt-2 p-2 rounded">
        <h3 className="text-info text-center"> Mail Sender</h3>
        <div className="mx-auto w-75">
          <h5>Select Vendor Names:-</h5>
          <Select
            isMulti
            options={vendors}
            value={selectedVendors}
            onChange={handleSelectChange}
            className="w-75"
          />
          <button
            onClick={handleButtonClick}
            disabled={!selectedVendors?.length}
            className="btn btn-primary mt-3"
          >
            Send Emails
          </button>
        </div>
        <div className="bg-light w-75 mx-auto mt-4 rounded">
          <table className="table  table-striped table-hover table-bordered ">
            <thead>
              <tr>
                <th className="text-center">Sr.No</th>
                <th className="text-center">Email</th>
                <th className="text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <>
                  <tr>
                    <td className="text-center" colSpan={3}>
                      loading.....
                    </td>
                  </tr>
                </>
              ) : (
                <>
                  {response ? (
                    Object.entries(response).map((email, index) => (
                      <>
                        <tr key={email as any}>
                          <td className="text-center">{index + 1}</td>
                          <td className="text-center">{email[0]}</td>
                          <td className="text-center">
                            {response[email[0]].toString()}
                          </td>
                        </tr>
                      </>
                    ))
                  ) : (
                    <>
                      <tr>
                        (
                        <td className="text-center" colSpan={3}>
                          No Records Present
                        </td>
                        )
                      </tr>
                    </>
                  )}
                </>
              )}
            </tbody>
          </table>
        </div>
        {/* <ul className="list-group">
          {emailStatusArray1.map(([email, status]) => (
            <li key={email} className="list-group-item">
              <strong>{email}</strong> - {status}
            </li>
          ))}
        </ul> */}
      </div>
    </>
  );
}
