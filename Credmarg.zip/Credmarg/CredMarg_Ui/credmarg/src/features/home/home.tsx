import React from "react";
import { Link } from "react-router-dom";
export default function HomePage() {
  return (
    <>
      <div className=" w-90 bg bg-secondary mt-2 p-2 rounded">
        <h3 className="text-info text-center">Descriptions</h3>

        <div className="card w-75 mx-auto m-4">
          <div className="card-header fw-bold text-center">Employee Page</div>
          <div className="card-body">
            <h6 className="card-title">Add Employee</h6>
            <p className="card-text">
              Using this functionality we can add employee by providing details
              like name,email,designation & ctc.
            </p>
            <hr />
            <h6 className="card-title">Edit Employee</h6>
            <p className="card-text">
              Using this functionality we can update employee details like
              name,email,designation & ctc.
            </p>
            <hr />
            <h6 className="card-title">Delete Employee</h6>
            <p className="card-text">
              Using this functionality we can delete unwanted employee details.
            </p>
            <Link to="/employees" className="btn btn-primary">
              view
            </Link>
          </div>
        </div>
        <div className="card w-75 mx-auto">
          <div className="card-header fw-bold text-center">Vendors Page</div>
          <div className="card-body">
            <h6 className="card-title">Add Vendor</h6>
            <p className="card-text">
              Using this functionality we can add vendors by providing details
              like name,email & UPI id.
            </p>
            <hr />
            <h6 className="card-title">Edit Vendors</h6>
            <p className="card-text">
              Using this functionality we can update vendors details like
              name,email & UPI id.
            </p>
            <hr />
            <h6 className="card-title">Delete Vendor</h6>
            <p className="card-text">
              Using this functionality we can delete unwanted vendor details.
            </p>
            <Link to="/Vendors" className="btn btn-primary">
              view
            </Link>
          </div>
        </div>

        <div className="card w-75 mx-auto m-4">
          <div className="card-header fw-bold text-center">Mailing Page</div>
          <div className="card-body">
            <h6 className="card-title">Select vendors</h6>
            <p className="card-text">
              Using this functionality we can add vendors to trigger email by
              selecting from dropdown contains all vendor list.
            </p>
            <hr />
            <h6 className="card-title">status Table</h6>
            <p className="card-text">
              By this functionality we are able to see the email Id's, status of
              email that are selected for send an email.
            </p>

            <Link to="/mails" className="btn btn-primary">
              view
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
