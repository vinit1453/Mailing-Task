// src/services/api.js
import axios from "axios";

const API_URL = process.env.REACT_APP_PORT;

export interface Iemployee {
  id: String;
  name: String;
  designation: String;
  ctc: Number;
  email: String;
}
export interface Ivendor {
  id: String;
  name: String;
  upiId: String;
  email: String;
}
export const createEmployee = async (employee: Iemployee) => {
  try {
    const apidata = await axios({
      method: "post",
      url: `${API_URL}/api/employee/add`,
      data: {
        name: employee?.name,
        email: employee?.email,
        designation: employee?.designation,
        ctc: employee?.ctc,
      },
    });

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};

export const updateanEmployee = async (employee: Iemployee) => {
  try {
    const apidata = await axios({
      method: "post",
      url: `${API_URL}/api/employee/update`,
      data: {
        id: employee?.id,
        name: employee?.name,
        email: employee?.email,
        designation: employee?.designation,
        ctc: employee?.ctc,
      },
    });

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};
export const getAllEmployees = async () => {
  try {
    const apidata = await axios.get(`${API_URL}/api/employee/employeeList`);

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};
export const deleteEmployees = async (id: String) => {
  //console.log("id", id);
  try {
    const apidata = await axios.delete(`${API_URL}/api/employee/delete/${id}`);
    // console.log("res", apidata);
    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};

export const createVendor = async (vendor: Ivendor) => {
  try {
    const apidata = await axios({
      method: "post",
      url: `${API_URL}/api/vendors/add`,
      data: {
        name: vendor?.name,
        email: vendor?.email,
        upiId: vendor?.upiId,
      },
    });
    //console.log("api data ", apidata);
    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};
export const getAllVendors = async () => {
  try {
    const apidata = await axios.get(`${API_URL}/api/vendors/vendorsList`);

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};
export const updateAVendor = async (vendor: Ivendor) => {
  try {
    const apidata = await axios({
      method: "post",
      url: `${API_URL}/api/vendors/update`,
      data: {
        id: vendor?.id,
        name: vendor?.name,
        email: vendor?.email,
        upiId: vendor?.upiId,
      },
    });

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};

export const deleteVendor = async (id: String) => {
  try {
    const apidata = await axios.delete(`${API_URL}/api/vendors/delete/${id}`);
    //console.log("res", apidata);
    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};

export const sendMails = async (ids: string[]) => {
  try {
    const apidata = await axios({
      method: "post",
      url: `${API_URL}/api/mail/sendEmails`,
      data: {
        emailsList: ids,
      },
    });

    return apidata.data;
  } catch (exception) {
    console.log("error ", exception);
  }
};
