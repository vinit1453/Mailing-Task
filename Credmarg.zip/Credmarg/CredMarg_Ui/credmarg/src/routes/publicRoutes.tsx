import React from "react";
import { Routes, Route } from "react-router-dom";

export default function publicRoutes() {
  return (
    <>
      <Routes>
        <Route path="/*" element={<></>} />;
        <Route path="/login" element={<></>} />;
        <Route path="/register" element={<></>} />;
      </Routes>
    </>
  );
}
