import React, { Suspense, useContext, useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useNavigate,
  useLocation,
  BrowserRouter,
} from "react-router-dom";
import PublicRoutes from "./publicRoutes";
import PrivateRoutes from "./privateRoutes";
import Navbar from "../features/navbar/navbar";
export default function Index() {
  return (
    <BrowserRouter>
      <>
        <PublicRoutes />
      </>

      <>
        <Navbar />
        <PrivateRoutes />
      </>
    </BrowserRouter>
  );
}

function Loader() {
  return (
    <>
      <div className="lds-roller">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </>
  );
}
