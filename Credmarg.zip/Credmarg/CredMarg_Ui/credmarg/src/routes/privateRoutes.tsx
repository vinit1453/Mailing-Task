import React from "react";
import { Routes, Route } from "react-router-dom";
import EmployeeTable from "../features/employee/employeeTable";
import VendorTable from "../features/vendor/vendorTable";
import MailPage from "../features/mail/mailPage";
import HomePage from "../features/home/home";
export default function privateRoutes() {
  return (
    <>
      <div className="w-90">
        <Routes>
          <Route path="/*" element={<></>} />;
          <Route path="/" element={<HomePage />} />;
          <Route
            path="/employees"
            element={<EmployeeTable name="Employee Table" />}
          />
          ;
          <Route path="/vendors" element={<VendorTable />} />;
          <Route path="/mails" element={<MailPage />} />;
        </Routes>
      </div>
    </>
  );
}
